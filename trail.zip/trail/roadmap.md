# Account, properties and document requirements
- [ ] Add owner-only editable profile and reusable private company documents; lock verified national IDs.
- [ ] Add My Properties tabs and renewal eligibility within 60 days or after expiry; preserve valid-only amendments.
- [ ] Merge tracking pages with legacy redirect, owner history/notes and missing-document upload.
- [ ] Add database document profiles, plot assignment, immutable application snapshots and admin controls.
- [ ] Verify signed-in flows, access isolation and rule tests.

# Application tracking and property selection
- [x] Add atomic immutable ACUD tracking numbers and display/search them throughout applicant/admin/follow-up/notification views; existing request backfilled.
- [x] Prevent conflicting property/unit submissions at the database and before document uploads; preserve linked follow-ups with one open follow-up per original.
- [x] Allow renewals/amendments only while the original license is still valid (not expired); enforced in the database trigger, wizard only lists valid licenses, PGlite tests cover pre-issuance and post-expiry rejection.
- [x] Replace example/free-text plot selection with one validated catalog selection and floor/unit fields; unapproved catalogs block submission honestly.
- [x] Insert a temporary sample plot catalog for every New Capital district (including H5/SI4/N1 with unit fields) and label it as sample data in the picker.
- [ ] Replace the sample plot catalog with the official district plot locations and verify map selection (blocked: official plot dataset required).
- [x] Verify signed-in 12-file submission/read-back, duplicate error with tracking ID, invalid code rejection, mobile overflow and PostgreSQL rules; temporary plot/request/files removed.

# Page consistency
- [x] Save incomplete licensing requests as private account drafts; verified save, reload, restoration, account listing and removal. Attachments must be selected again.
- [x] Schedule daily account renewal reminders for issued licenses within 30 days and on expiry; active schedule and first run verified, no eligible issued licenses currently exist to visually verify reminder delivery.
- [x] Extend the bilingual site-only assistant without history storage; verified English portal answer, Arabic off-topic refusal, follow-up history and mobile layout. All request tests pass; repository lint remains blocked by widespread existing formatting errors.
- [x] Remove Lovable sign-in button; verify successful signup to confirmation-pending state, detect bounced confirmation emails and show specific error guidance.
- [x] Provision the designated company administrator securely; adapt uploaded administration views to live portal data, verify non-admin denial and submit/review/read-back flow.
- [ ] Connect Egyptian hosted card checkout and verified email receipts (blocked: company needs to create and obtain approval for a Paymob merchant account, then supply credentials; receipt sending also needs email setup).
- [x] Add owner-only trash actions for every request kind; verified cancel, real request removal, refreshed account lists, reload persistence and inaccessible-request rejection.
- [x] Speed up attachment uploads with three concurrent transfers, progress and resume; verified real storage upload, interrupted-upload retry and account read-back, and removed test data.
- [x] Update inquiry search wording and replace its three actions with previous requests; verified navigation.
- [x] Hide building fees until selection and use building-specific name fields.
- [x] Add owner-private account/request notifications next to the user's name; verify real submission and persistent read state.
- [x] Open homepage after sign-in and add gentle choice hover effects; verify signed-in navigation and phone layout.
- [x] Keep footers bottom-aligned, unify typography, and verify page/step transitions start at the top.

# Website import
- [x] Import the supplied homepage and its media.
- [x] Repair font loading and mobile navigation.
- [x] Verify sections and controls at desktop and phone sizes.

# Portal changes
- [ ] Email every new question, feedback, and complaint to the designated support recipient (blocked until an owned sender domain is configured).
- [x] Check every existing menu and destination and report any unavailable functionality (existing linked account/licensing pages are not imported).
- [x] Update the main image heading and request-review labels.
- [x] Remove the government complaints card and split FAQ/questions from complaints with their requested forms.
- [x] Verify new pages, saved forms, and navigation.

# Account access and missing destinations
- [x] Restyle sign-in and two-step signup with three account types, national ID, and password confirmation; verify validation and navigation.
- [x] Reproduce missing service/account pages and verify FAQ and complaints remain accessible.
- [x] Add account creation/sign-in with name and mobile profiles and account-required service destinations.
- [x] Verify signed-out redirects, signed-in destinations using a managed account session, sign-out, and public FAQ/complaint access.
- [ ] Complete successful new-account email confirmation check (requires a real receiving email; reserved test domains are rejected).
- [x] Build licensing submission forms and connect owner request/license records; issued licenses appear only after real issuance.

# Licensing workflow expansion
- [x] Fill request identification from selected Google place markers in every district; bounded authenticated search and bilingual notice added, all 90 tests passed, signed-in request page verified without Maps calls; live marker selection remains unverified until checked on an authorized deployed origin.
- [x] Add optional Google Maps point selection and persist validated applicant-selected coordinates separately from parcel numbers; 35 tests passed and signed-in district selection checked without Maps calls. Live selection and submission with coordinates require deployed Maps verification.
- [x] Rename the investor district to حي الاعمال المركزية بالعاصمة الادارية while preserving existing request identifiers.
- [x] Keep temporary plot examples with a prominent bilingual fictional/unapproved-data notice as requested.
- [ ] Replace synthetic plot chips with authoritative district lists in settings and nightly updates (blocked: Google Places is not a parcel registry; obtain an official dataset and confirm its update source).
- [x] Suggest additional portal improvements without implementing unrequested features.
- [x] Add homepage support contacts and rename the licensing service.
- [x] Add company and licensing-type selection with the specified building prices.
- [ ] Confirm the missing area bracket and obtain authoritative plot locations/areas for the six districts.
- [x] Add declared plot number/area, approved fee calculation, all 12 PDF uploads, and saved account requests; no fabricated map parcels.
- [x] Support offline treasury payment instructions, explicitly unpaid.
- [ ] Connect online card payment (requires an approved Egypt-compatible payment provider/account; built-in providers are ineligible).
- [x] Add annual renewal and activity/ownership amendments linked to the original request; unspecified fees await company review.
- [ ] Enable authoritative map plot selection (requires an official parcel dataset with locations and unit areas).
- [ ] Validate Google Maps on an authorized deployed origin (sandbox live Maps checks are unsupported).
- [x] Test all specified prices and required uploads; submit and read back new, renewal and ownership requests with a managed signed-in session; verify phone layout and remove test requests.

# Contact, language and motion
- [x] Public Contact Us page in the navbar with official ACUD contact details, form and map.
- [x] Arabic/English switch for header, footer, homepage and contact page.
- [ ] English for the remaining inner pages (application forms, account, admin) — not yet translated.
- [x] Glass header, hero entrance and one-by-one scroll reveal; ACUD-style footer; darker navy.
