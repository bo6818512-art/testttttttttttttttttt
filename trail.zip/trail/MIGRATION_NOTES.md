# Legacy Data Export Notes

Prepare UTF-8 CSV exports with the exact staging headers below. If the legacy database uses different names, map its columns to these headers during export. Preserve legacy IDs as references; do not reuse them as Supabase UUIDs.

Do not export `password`, `password_hash`, access tokens, or service credentials. Existing users will sign in through the password-reset flow.

## users.csv

One row per legacy account.

```text
old_user_id,email,full_name,phone,national_id,account_type,created_at,email_confirmed_at
```

Match users to newly provisioned `auth.users` records by normalized email, then map `old_user_id` to the new auth UUID. Create the owner profile with `full_name`, `phone`, `national_id`, and `account_type`. Do not import legacy role or privilege fields as applicant permissions; administrator roles must be assigned separately through the approved admin process.

## requests.csv

One row per non-issued request, including renewal and amendment requests.

```text
old_request_id,old_user_id,parent_old_request_id,old_plot_id,kind,license_type,building_type,district,plot_number,area,floor,unit_number,activity,activity_category,owner_name,owner_type,fee,payment_method,status,created_at,old_tracking_id,selected_location,paid_at,documents_approved_at,receipt_path,receipt_uploaded_at,deleted_at
```

Map `old_user_id`, `parent_old_request_id`, and `old_plot_id` through explicit legacy-to-new ID maps. The destination is `public.license_requests`. Convert legacy statuses to the destination status values before import; do not invent review or payment events. `old_tracking_id` is retained in the staging map only: the destination trigger generates immutable `ACUD_` tracking IDs and overrides applicant-supplied values.

## licenses.csv

One row per issued or historical license. If the license belongs to an exported request, set `old_request_id` so it can be joined rather than duplicated.

```text
old_license_id,old_request_id,old_user_id,old_plot_id,license_number,license_type,building_type,district,plot_number,area,floor,unit_number,activity,owner_name,owner_type,fee,issued_at,expires_at,paid_at,created_at
```

Issued licenses are represented by `public.license_requests` rows with `status='issued'`; the destination does not have a separate licenses table. Preserve `old_license_id` and the source `license_number` in the staging crosswalk. The destination `license_number` is managed from the new tracking ID during issuance and must not be overwritten with a legacy number.

## plots.csv

One row per legacy plot/property.

```text
old_plot_id,code,district,has_units,latitude,longitude,enabled,profile_id
```

Map `old_plot_id` to a new `public.licensing_plots.id`. Keep the old plot code and district as source values in the crosswalk. The applicant UI currently exposes only `RES`, `FIN`, `MU`, and `GOV2`; the database may retain other legacy districts, but they will not be selectable through that UI. Confirm plot codes and coordinate order before import; GeoJSON coordinates are `[longitude,latitude]`.

## documents.csv

One row per legacy requirement-profile/document assignment.

```text
document_id,document_name,requirement_profile,is_required,condition
```

Map these rows to `public.documents` and `public.profile_documents`. Match requirement-profile names to destination IDs such as `standard` and `company_owned`; do not infer a profile from an applicant's account type.

## request_documents.csv

One row per uploaded file attached to a legacy request or license.

```text
old_request_id,old_license_id,document_id,document_name,old_storage_path,old_storage_bucket,mime_type,uploaded_at
```

Export the corresponding file bytes separately while preserving `old_storage_path` in the manifest. Upload files into the destination private storage bucket under the new owner/request path, then map them to `public.application_documents`. Never publish legacy file URLs or copy them into public storage. Keep missing or non-PDF files flagged for manual review rather than marking them as valid submissions.

## Import Order

1. Export and retain immutable crosswalks for users, plots, requests, and licenses.
2. Provision users and map each `old_user_id` to the new auth UUID; users complete password reset before sign-in.
3. Import plots and map each `old_plot_id` to its new plot UUID.
4. Import pending requests and issued licenses into `public.license_requests`, resolving owner, parent, and plot references. Allow the database to generate new tracking IDs.
5. Import the document catalog/profile matrix, then transfer file bytes and import the request-document manifest.
6. Reconcile row counts, owner mappings, tracking IDs, license dates, document snapshots, and private storage paths before enabling applicant access.

The legacy source schema and file archive are not present in this repository. These headers define the required export contract; verify every source-to-header mapping with the old-system owner before importing production data.