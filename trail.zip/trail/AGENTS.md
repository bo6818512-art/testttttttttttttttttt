<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep imported page markup and interaction state in its route file, preserving source CSS separately, to allow faithful repairs.
- Bundle imported fonts through Vite asset imports so their URLs resolve in preview and published builds.
- Portal pages use full-viewport flex columns with a growing main area; typography inherits the global font token and resolved navigation resets window scroll, keeping short pages bottom-aligned and transitions consistent.
- New support pages use a shared portal page frame while their content and form state remain in their leaf routes, preserving the imported homepage.
- Public support submissions use a validated server function and insert-only database permissions; no visitor may read other submissions.
- Account state has one root auth subscriber; service routes live under the client-only _authenticated gate, while public support and account pages remain top-level, to prevent unauthorized page access and keep email callbacks reachable.
- Account profiles are created by a signup trigger with owner-only reads and updates; do not use profile metadata for permissions.
- Registration categories are self-declared profile information only, never authorization roles; national IDs stay in owner-only profiles, and signup uses a two-step form with shared password controls.
- Licensing destinations must show honest unavailable states until approved forms and request records are connected; never fabricate licenses or claim submissions succeeded.
- Licensing uses shared wizard/catalog modules and owner-scoped server functions; database validation enforces fees, all twelve stored PDFs, parent ownership and immutable locations for follow-ups to prevent bypassing client controls.
- License documents are private, owner-prefixed storage objects and become immutable after request submission; request creation never marks treasury payments paid or licenses issued.
- Google Maps shows provider-resolved district locations only; applicant-supplied plot numbers and unit areas are unverified until reviewed against documents, because Places does not provide an authoritative licensing parcel registry.
- Generate temporary plot examples through the licensing catalog helper so displayed ranges remain testable independently of the wizard.
- District maps retain the public Google embed for viewing and offer a Maps JavaScript point picker with the managed browser key; persist validated applicant coordinates separately from unverified plot numbers and inherit immutable parent locations for follow-ups.
- Named map selection opens by default and uses app-owned markers from bounded authenticated Places API (New) searches; place search/list selection remains available independently of map loading, fills request identification without claiming a parcel number, and browser POI/Places calls remain disabled.
- Account notifications are created by profile/request database triggers, owner-readable with read-state-only updates, and refreshed through a cleaned-up Realtime subscription; this keeps events durable and private.
- Whole-building names use the existing request identification field to preserve original-request and follow-up compatibility.
- License document uploads use a bounded client-side worker pool and cache completed files per request; retry only unfinished or replaced files, preserving immutable submitted storage objects.
- Owner request deletion is a soft deletion through an auth-checked database function; every account list and follow-up selector excludes removed requests while preserving independent follow-ups and submitted documents.
- The licensing assistant answers only from a prompt generated from the licensing catalog module through a public streaming server route without private-data access; keeping one source prevents stale fees or documents.
- Administration adapts the uploaded RTL layout to the existing portal tables under a nested role-gated section; authenticated server functions and database functions verify separate assigned roles, keeping self-declared signup categories non-privileged.
- Licensing requests move document review -> payment (owner receipt upload) -> payment confirmation -> issuance through audited database functions; fees stay hidden from applicants until documents are approved, preventing UI or direct-call bypasses.
- The admin dashboard refreshes authorized portal reads periodically and on focus; imported demo records, foreign backend settings and archive credentials are never merged into this project's data.
- Interface language (English default, Arabic) comes from one root LanguageProvider persisted in localStorage; shared UI uses keys in src/lib/i18n.tsx and inner-page Arabic text is swapped via the meaning-based phrase map in src/lib/page-translations.ts, so every page switches without reload.
- The site header and footer are shared components used by every page, so navigation links and quick links stay identical.
- Incomplete licensing data lives in owner-only drafts, separate from submitted requests; restore validated fields without persisting browser File objects or bypassing submission checks.
- Renewal notifications use a daily SQL-only scheduled function with unique per-expiry event keys; exclude removed and superseded licenses to prevent duplicate alerts.
- The portal assistant uses a public catalog-based streaming endpoint and a site-wide AI Elements floating launcher with ephemeral history; no account is needed and the Help page does not duplicate it.
- Licensing plot selection reads the approved catalog only; one shared picker maps code and map-marker choices to the same property UUID, preventing synthetic or free-text parcel submissions.
- Database sequences/triggers own immutable tracking numbers; property-slot indexes and a bounded auth-checked conflict RPC protect concurrent submissions without exposing applicant details.
