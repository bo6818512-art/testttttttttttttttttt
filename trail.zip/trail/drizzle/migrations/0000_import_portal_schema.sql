CREATE TABLE public.support_submissions (
 id uuid PRIMARY KEY,
 created_at timestamptz NOT NULL DEFAULT now(),
 kind text NOT NULL CHECK (kind IN ('question','feedback','complaint')),
 name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 100),
 email text NOT NULL CHECK (char_length(email) <= 255 AND email ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'),
 phone text NOT NULL DEFAULT '' CHECK (char_length(phone) <= 30),
 complaint_type text NOT NULL DEFAULT '' CHECK (char_length(complaint_type) <= 100),
 message text NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 5000),
 CHECK (kind <> 'complaint' OR (phone ~ '^[+0-9 ()-]{7,30}$' AND char_length(btrim(complaint_type)) > 0))
);
GRANT INSERT ON public.support_submissions TO anon, authenticated;
GRANT ALL ON public.support_submissions TO service_role;
ALTER TABLE public.support_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors may submit support messages" ON public.support_submissions FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE TABLE public.profiles (
 id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 full_name text NOT NULL DEFAULT '',
 phone text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now(),
 national_id text CHECK (national_id IS NULL OR national_id ~ '^[0-9]{14}$'),
 requested_account_type text CONSTRAINT profiles_requested_account_type_valid CHECK (requested_account_type IS NULL OR requested_account_type IN ('citizen', 'acud', 'capital_authority', 'developer'))
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own profile" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY "Update own profile" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE FUNCTION public.create_portal_profile() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 INSERT INTO public.profiles (id, full_name, phone, national_id, requested_account_type)
 VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), COALESCE(NEW.raw_user_meta_data->>'phone', ''), NEW.raw_user_meta_data->>'national_id', NEW.raw_user_meta_data->>'requested_account_type');
 RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.create_portal_profile() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER on_portal_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.create_portal_profile();

CREATE TABLE public.license_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 kind text NOT NULL DEFAULT 'new' CHECK (kind IN ('new','renewal','activity_change','ownership_transfer')),
 parent_id uuid REFERENCES public.license_requests(id),
 license_type text NOT NULL CHECK (license_type IN ('building','unit')), building_type text, district text, plot_number text NOT NULL, area integer, activity text NOT NULL, owner_name text NOT NULL, fee integer,
 payment_method text NOT NULL CHECK (payment_method IN ('offline','online')),
 status text NOT NULL DEFAULT 'awaiting_document_review',
 documents jsonb NOT NULL DEFAULT '[]'::jsonb, issued_at timestamptz, expires_at timestamptz,
 deleted_at timestamptz, paid_at timestamptz, selected_location jsonb,
 owner_type text CHECK (owner_type IS NULL OR owner_type IN ('company','individual')),
 documents_approved_at timestamptz, receipt_path text, receipt_uploaded_at timestamptz,
 CONSTRAINT license_requests_status_check CHECK (status IN ('awaiting_document_review','awaiting_payment','awaiting_payment_review','under_review','issued','rejected'))
);
GRANT SELECT, INSERT ON public.license_requests TO authenticated;
GRANT ALL ON public.license_requests TO service_role;
ALTER TABLE public.license_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read licensing requests" ON public.license_requests FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Owners submit licensing requests" ON public.license_requests FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.validate_license_request() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE expected_fee integer; document_count integer;
BEGIN
 IF NEW.kind <> 'new' THEN
  IF NEW.parent_id IS NULL OR NOT EXISTS (SELECT 1 FROM public.license_requests r WHERE r.id = NEW.parent_id AND r.user_id = NEW.user_id AND r.kind = 'new') THEN RAISE EXCEPTION 'An owned original request is required'; END IF;
  IF NEW.fee IS NOT NULL THEN RAISE EXCEPTION 'Follow-up fees require review'; END IF;
 ELSE
  IF NEW.parent_id IS NOT NULL THEN RAISE EXCEPTION 'New requests cannot have a parent'; END IF;
  IF NEW.owner_type IS NULL THEN RAISE EXCEPTION 'Owner type required'; END IF;
  IF NEW.license_type = 'building' THEN
   expected_fee := CASE NEW.building_type WHEN 'compounds' THEN 33000 WHEN 'hospitals' THEN 16500 WHEN 'schools' THEN 22000 WHEN 'universities' THEN 22000 WHEN 'clubs' THEN 22000 WHEN 'malls' THEN 22000 WHEN 'administrative' THEN 22000 WHEN 'mixed' THEN 21000 WHEN 'fuel' THEN 21000 ELSE NULL END;
  ELSE
   IF NEW.area IS NULL OR NEW.area <= 0 THEN RAISE EXCEPTION 'Valid area required'; END IF;
   expected_fee := CASE WHEN NEW.area <= 50 THEN 4000 WHEN NEW.area <= 100 THEN 5000 WHEN NEW.area BETWEEN 151 AND 200 THEN 7000 WHEN NEW.area > 200 THEN 11000 ELSE NULL END;
   IF NEW.district IS NULL OR NEW.district NOT IN ('DIP','FIN','GOV2','INV','RES','MU','R7','R8') THEN RAISE EXCEPTION 'District required'; END IF;
  END IF;
  IF expected_fee IS NULL OR NEW.fee IS DISTINCT FROM expected_fee THEN RAISE EXCEPTION 'Fee is unavailable or incorrect'; END IF;
 END IF;
 IF NEW.status <> 'awaiting_document_review' THEN RAISE EXCEPTION 'New requests must await document review'; END IF;
 IF NEW.payment_method <> 'offline' THEN RAISE EXCEPTION 'Online payments are not enabled'; END IF;
 IF NEW.issued_at IS NOT NULL OR NEW.expires_at IS NOT NULL OR NEW.paid_at IS NOT NULL OR NEW.documents_approved_at IS NOT NULL OR NEW.receipt_path IS NOT NULL THEN RAISE EXCEPTION 'Applicants cannot set review fields'; END IF;
 IF length(trim(NEW.plot_number)) = 0 OR length(trim(NEW.owner_name)) = 0 OR length(trim(NEW.activity)) = 0 THEN RAISE EXCEPTION 'Request details required'; END IF;
 IF jsonb_typeof(NEW.documents) <> 'array' OR jsonb_array_length(NEW.documents) <> 12 THEN RAISE EXCEPTION 'All twelve documents are required'; END IF;
 SELECT count(DISTINCT (d->>'slot')::integer) INTO document_count FROM jsonb_array_elements(NEW.documents) d WHERE (d->>'slot')::integer BETWEEN 1 AND 12 AND d->>'path' = NEW.user_id::text || '/' || NEW.id::text || '/' || (d->>'slot') || '.pdf' AND EXISTS (SELECT 1 FROM storage.objects o WHERE o.bucket_id = 'license-documents' AND o.name = d->>'path' AND o.metadata->>'mimetype' = 'application/pdf');
 IF document_count <> 12 THEN RAISE EXCEPTION 'Twelve stored PDF documents required'; END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER validate_license_request_before_insert BEFORE INSERT ON public.license_requests FOR EACH ROW EXECUTE FUNCTION public.validate_license_request();

CREATE OR REPLACE FUNCTION public.validate_license_followup() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE original public.license_requests;
BEGIN
 IF NEW.kind = 'new' THEN RETURN NEW; END IF;
 SELECT * INTO original FROM public.license_requests WHERE id = NEW.parent_id AND user_id = NEW.user_id AND kind = 'new';
 IF NOT FOUND THEN RAISE EXCEPTION 'Owned original request required'; END IF;
 IF NEW.license_type IS DISTINCT FROM original.license_type OR NEW.building_type IS DISTINCT FROM original.building_type OR NEW.district IS DISTINCT FROM original.district OR NEW.plot_number IS DISTINCT FROM original.plot_number OR NEW.area IS DISTINCT FROM original.area THEN RAISE EXCEPTION 'Follow-ups cannot change location or building'; END IF;
 IF NEW.kind <> 'activity_change' AND NEW.activity IS DISTINCT FROM original.activity THEN RAISE EXCEPTION 'Only activity amendments may change activity'; END IF;
 IF NEW.kind <> 'ownership_transfer' AND (NEW.owner_name IS DISTINCT FROM original.owner_name OR NEW.owner_type IS DISTINCT FROM original.owner_type) THEN RAISE EXCEPTION 'Only ownership transfers may change owner'; END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER validate_license_followup_before_insert BEFORE INSERT ON public.license_requests FOR EACH ROW EXECUTE FUNCTION public.validate_license_followup();

CREATE POLICY "Owners upload private licensing PDFs" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'license-documents' AND (storage.foldername(name))[1] = auth.uid()::text AND lower(storage.extension(name)) = 'pdf' AND storage.filename(name) NOT LIKE 'receipt%');
CREATE POLICY "Owners upload payment receipts" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'license-documents' AND (storage.foldername(name))[1] = auth.uid()::text AND storage.filename(name) LIKE 'receipt-%' AND lower(storage.extension(name)) IN ('pdf','jpg','jpeg','png','webp') AND EXISTS (SELECT 1 FROM public.license_requests r WHERE r.id::text = (storage.foldername(name))[2] AND r.user_id = auth.uid() AND r.status = 'awaiting_payment' AND r.deleted_at IS NULL));
CREATE POLICY "Owners read private licensing PDFs" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'license-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Owners remove unattached licensing PDFs" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'license-documents' AND (storage.foldername(name))[1] = auth.uid()::text AND NOT EXISTS (SELECT 1 FROM public.license_requests r WHERE r.id::text = (storage.foldername(name))[2] AND r.user_id = auth.uid()));

CREATE TABLE public.account_notifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL,
 request_id uuid REFERENCES public.license_requests(id) ON DELETE CASCADE,
 title text NOT NULL, message text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), read_at timestamptz, event_key text
);
GRANT SELECT ON public.account_notifications TO authenticated;
GRANT UPDATE (read_at) ON public.account_notifications TO authenticated;
GRANT ALL ON public.account_notifications TO service_role;
ALTER TABLE public.account_notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read account notifications" ON public.account_notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Owners mark notifications read" ON public.account_notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX account_notifications_owner_created ON public.account_notifications(user_id, created_at DESC);
CREATE UNIQUE INDEX account_notifications_event_key ON public.account_notifications(event_key) WHERE event_key IS NOT NULL;

CREATE OR REPLACE FUNCTION public.notify_portal_account_created() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 INSERT INTO public.account_notifications(user_id,title,message) VALUES(NEW.id,'أهلًا بك في بوابة التراخيص','تم إنشاء حسابك. يمكنك اختيار الخدمة من الصفحة الرئيسية.');
 RETURN NEW;
END;
$$;
CREATE TRIGGER notify_portal_profile_created AFTER INSERT ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.notify_portal_account_created();
CREATE OR REPLACE FUNCTION public.notify_license_request_event() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE event_title text; event_message text;
BEGIN
 IF TG_OP = 'INSERT' THEN
  event_title := 'تم رفع جميع المستندات';
  event_message := 'تم رفع جميع الملفات وفي انتظار مراجعة الإدارة للأوراق خلال 48 ساعة، وسيتم إخطاركم برسالة الدفع.';
 ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
  event_title := 'تحديث على طلبك';
  event_message := CASE NEW.status
   WHEN 'awaiting_payment' THEN 'تمت الموافقة على مستنداتك. يمكنك الآن الدفع ورفع صورة الإيصال من صفحة طلباتي. الرسوم: ' || COALESCE(NEW.fee::text, '') || ' جنيه مصري.'
   WHEN 'awaiting_payment_review' THEN 'تم استلام إيصال الدفع. سيتم مراجعة الطلب وإصدار الترخيص خلال 30 يومًا من الدفع ورفع المستندات.'
   WHEN 'under_review' THEN 'تم تأكيد السداد؛ طلبك قيد المراجعة النهائية.'
   WHEN 'issued' THEN 'تم إصدار الترخيص.'
   WHEN 'rejected' THEN 'تم رفض الطلب. راجع ملاحظات الإدارة.'
   ELSE NEW.status END;
  IF NEW.status = 'awaiting_payment' THEN event_title := 'رسالة الدفع'; END IF;
 ELSE RETURN NEW;
 END IF;
 INSERT INTO public.account_notifications(user_id,request_id,title,message) VALUES(NEW.user_id,NEW.id,event_title,event_message);
 RETURN NEW;
END;
$$;
CREATE TRIGGER notify_license_request_changes AFTER INSERT OR UPDATE ON public.license_requests FOR EACH ROW EXECUTE FUNCTION public.notify_license_request_event();
REVOKE EXECUTE ON FUNCTION public.notify_portal_account_created() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.notify_license_request_event() FROM PUBLIC, anon, authenticated;
ALTER PUBLICATION supabase_realtime ADD TABLE public.account_notifications;

CREATE OR REPLACE FUNCTION public.delete_own_license_request(request_id uuid) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE removed_id uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 UPDATE public.license_requests SET deleted_at = now() WHERE id = request_id AND user_id = auth.uid() AND deleted_at IS NULL RETURNING id INTO removed_id;
 IF removed_id IS NULL THEN RETURN false; END IF;
 INSERT INTO public.account_notifications(user_id,title,message) VALUES(auth.uid(),'تم حذف الطلب','تم حذف الطلب من قائمة طلباتك.');
 RETURN true;
END;
$$;
REVOKE ALL ON FUNCTION public.delete_own_license_request(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_own_license_request(uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.reject_deleted_license_parent() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF NEW.parent_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.license_requests WHERE id = NEW.parent_id AND deleted_at IS NOT NULL) THEN RAISE EXCEPTION 'Original request was deleted'; END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER reject_deleted_license_parent_before_insert BEFORE INSERT ON public.license_requests FOR EACH ROW EXECUTE FUNCTION public.reject_deleted_license_parent();

CREATE TYPE public.app_role AS ENUM ('admin');
CREATE TABLE public.user_roles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE, role public.app_role NOT NULL, UNIQUE(user_id, role));
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own assigned roles" ON public.user_roles FOR SELECT TO authenticated USING(user_id = auth.uid());
CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
CREATE TABLE public.admin_request_events (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), request_id uuid NOT NULL REFERENCES public.license_requests(id), actor_id uuid NOT NULL, action text NOT NULL, note text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT ON public.admin_request_events TO authenticated;
GRANT ALL ON public.admin_request_events TO service_role;
ALTER TABLE public.admin_request_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company admin reads request events" ON public.admin_request_events FOR SELECT TO authenticated USING(public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Company admin creates request events" ON public.admin_request_events FOR INSERT TO authenticated WITH CHECK(public.has_role(auth.uid(), 'admin') AND actor_id=auth.uid());
CREATE POLICY "Company admin reads portal requests" ON public.license_requests FOR SELECT TO authenticated USING(public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Company admin reads applicant profiles" ON public.profiles FOR SELECT TO authenticated USING(public.has_role(auth.uid(), 'admin'));
GRANT SELECT ON public.support_submissions TO authenticated;
CREATE POLICY "Company admin reads support inbox" ON public.support_submissions FOR SELECT TO authenticated USING(public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Company admin reads licensing files" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'license-documents' AND public.has_role(auth.uid(), 'admin'));

-- Step 1: admin approves documents and unlocks payment.
CREATE FUNCTION public.admin_approve_documents(request_id uuid, review_note text, reviewed_fee integer DEFAULT NULL) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE original public.license_requests;
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
 IF length(trim(review_note))=0 OR length(review_note)>2000 THEN RAISE EXCEPTION 'Invalid review'; END IF;
 SELECT * INTO original FROM public.license_requests WHERE id=request_id AND deleted_at IS NULL FOR UPDATE;
 IF NOT FOUND OR original.status <> 'awaiting_document_review' THEN RAISE EXCEPTION 'Request is not awaiting document review'; END IF;
 IF reviewed_fee IS NOT NULL AND (original.kind='new' OR reviewed_fee<=0 OR reviewed_fee>1000000) THEN RAISE EXCEPTION 'Invalid reviewed fee'; END IF;
 IF COALESCE(reviewed_fee, original.fee) IS NULL THEN RAISE EXCEPTION 'Fee required before payment'; END IF;
 UPDATE public.license_requests SET fee=COALESCE(reviewed_fee,fee), documents_approved_at=now(), status='awaiting_payment' WHERE id=request_id;
 INSERT INTO public.admin_request_events(request_id,actor_id,action,note) VALUES(request_id,auth.uid(),'documents_approved',review_note);
END; $$;
REVOKE ALL ON FUNCTION public.admin_approve_documents(uuid,text,integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_approve_documents(uuid,text,integer) TO authenticated;

-- Step 2: owner uploads payment receipt.
CREATE FUNCTION public.submit_payment_receipt(request_id uuid, receipt_path text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
 IF receipt_path NOT LIKE auth.uid()::text || '/' || request_id::text || '/receipt-%' OR NOT EXISTS (SELECT 1 FROM storage.objects o WHERE o.bucket_id='license-documents' AND o.name=receipt_path) THEN RAISE EXCEPTION 'Receipt file missing'; END IF;
 UPDATE public.license_requests SET receipt_path=submit_payment_receipt.receipt_path, receipt_uploaded_at=now(), status='awaiting_payment_review' WHERE id=request_id AND user_id=auth.uid() AND deleted_at IS NULL AND status='awaiting_payment';
 IF NOT FOUND THEN RAISE EXCEPTION 'Payment is not open for this request'; END IF;
END; $$;
REVOKE ALL ON FUNCTION public.submit_payment_receipt(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_payment_receipt(uuid,text) TO authenticated;

-- Step 3: admin confirms payment.
CREATE FUNCTION public.admin_confirm_treasury_payment(request_id uuid, receipt_reference text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
 IF length(trim(receipt_reference))<3 OR length(receipt_reference)>200 THEN RAISE EXCEPTION 'Receipt reference required'; END IF;
 UPDATE public.license_requests SET paid_at=now(), status='under_review' WHERE id=request_id AND deleted_at IS NULL AND paid_at IS NULL AND fee>0 AND status IN ('awaiting_payment','awaiting_payment_review');
 IF NOT FOUND THEN RAISE EXCEPTION 'Payment cannot be confirmed'; END IF;
 INSERT INTO public.admin_request_events(request_id,actor_id,action,note) VALUES(request_id,auth.uid(),'treasury_payment_confirmed',receipt_reference);
END; $$;
REVOKE ALL ON FUNCTION public.admin_confirm_treasury_payment(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_confirm_treasury_payment(uuid,text) TO authenticated;

-- Final: issue or reject.
CREATE FUNCTION public.admin_review_request(request_id uuid, next_status text, review_note text, reviewed_fee integer DEFAULT NULL) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE original public.license_requests;
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Forbidden'; END IF;
 IF next_status NOT IN ('under_review','issued','rejected') OR length(trim(review_note))=0 OR length(review_note)>2000 THEN RAISE EXCEPTION 'Invalid review'; END IF;
 SELECT * INTO original FROM public.license_requests WHERE id=request_id AND deleted_at IS NULL FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Request unavailable'; END IF;
 IF original.status='issued' THEN RAISE EXCEPTION 'Issued license cannot be reissued'; END IF;
 IF next_status IN ('under_review','issued') AND original.paid_at IS NULL THEN RAISE EXCEPTION 'Confirmed payment required'; END IF;
 IF reviewed_fee IS NOT NULL AND (original.kind='new' OR reviewed_fee<=0 OR reviewed_fee>1000000) THEN RAISE EXCEPTION 'Invalid reviewed fee'; END IF;
 UPDATE public.license_requests SET status=next_status, fee=COALESCE(reviewed_fee,fee), issued_at=CASE WHEN next_status='issued' THEN now() ELSE issued_at END, expires_at=CASE WHEN next_status='issued' THEN now()+interval '1 year' ELSE expires_at END WHERE id=request_id;
 INSERT INTO public.admin_request_events(request_id,actor_id,action,note) VALUES(request_id,auth.uid(),next_status,review_note);
END; $$;
REVOKE ALL ON FUNCTION public.admin_review_request(uuid,text,text,integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_review_request(uuid,text,text,integer) TO authenticated;

CREATE TABLE public.environmental_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  project_name text NOT NULL CHECK (char_length(project_name) BETWEEN 2 AND 200),
  documents jsonb NOT NULL,
  payment_method text NOT NULL CHECK (payment_method IN ('visa_at_office', 'online')),
  status text NOT NULL DEFAULT 'under_review',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.environmental_requests TO authenticated;
GRANT ALL ON public.environmental_requests TO service_role;
ALTER TABLE public.environmental_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read environmental requests" ON public.environmental_requests FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Owners create environmental requests" ON public.environmental_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE OR REPLACE FUNCTION public.validate_environmental_request()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE required_count integer;
BEGIN
  IF NEW.payment_method <> 'visa_at_office' THEN RAISE EXCEPTION 'Online payment is not available yet'; END IF;
  NEW.status := 'under_review';
  SELECT count(DISTINCT (d->>'slot')::integer) INTO required_count FROM jsonb_array_elements(NEW.documents) d
    WHERE (d->>'slot')::integer IN (1,2,3,4,5,6,8)
      AND d->>'path' LIKE NEW.user_id::text || '/env-' || NEW.id::text || '/%.pdf';
  IF required_count <> 7 THEN RAISE EXCEPTION 'All required environmental documents must be uploaded'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER validate_environmental_request_before_insert BEFORE INSERT ON public.environmental_requests FOR EACH ROW EXECUTE FUNCTION public.validate_environmental_request();

CREATE OR REPLACE FUNCTION public.validate_selected_license_location() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE parent_location jsonb;
BEGIN
 IF TG_OP = 'INSERT' AND NEW.kind <> 'new' THEN
  SELECT selected_location INTO parent_location FROM public.license_requests WHERE id = NEW.parent_id AND user_id = NEW.user_id;
  NEW.selected_location := parent_location;
 END IF;
 IF TG_OP = 'UPDATE' AND NEW.selected_location IS DISTINCT FROM OLD.selected_location THEN RAISE EXCEPTION 'Submitted locations are immutable'; END IF;
 IF NEW.selected_location IS NOT NULL THEN
  IF jsonb_typeof(NEW.selected_location) <> 'object' OR jsonb_typeof(NEW.selected_location->'lat') IS DISTINCT FROM 'number' OR jsonb_typeof(NEW.selected_location->'lng') IS DISTINCT FROM 'number' THEN RAISE EXCEPTION 'Invalid selected coordinates'; END IF;
  IF (NEW.selected_location->>'lat')::numeric NOT BETWEEN -90 AND 90 OR (NEW.selected_location->>'lng')::numeric NOT BETWEEN -180 AND 180 THEN RAISE EXCEPTION 'Selected coordinates out of range'; END IF;
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER validate_selected_license_location BEFORE INSERT OR UPDATE ON public.license_requests FOR EACH ROW EXECUTE FUNCTION public.validate_selected_license_location();

CREATE TABLE public.license_drafts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, mode text NOT NULL DEFAULT 'new' CHECK(mode IN ('new','renewal','amendment')), payload jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(payload)='object' AND octet_length(payload::text)<=20000), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.license_drafts TO authenticated;
GRANT ALL ON public.license_drafts TO service_role;
ALTER TABLE public.license_drafts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners manage request drafts" ON public.license_drafts FOR ALL TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE INDEX license_drafts_owner ON public.license_drafts(user_id,updated_at DESC);

CREATE OR REPLACE FUNCTION public.send_license_renewal_alerts() RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE inserted_count integer;
BEGIN
 INSERT INTO public.account_notifications(user_id,request_id,title,message,event_key)
 SELECT r.user_id,r.id,CASE WHEN r.expires_at<=now() THEN 'انتهت صلاحية الترخيص' ELSE 'تذكير بتجديد الترخيص' END,
 CASE WHEN r.expires_at<=now() THEN 'انتهت صلاحية ترخيص ' ELSE 'اقترب موعد انتهاء ترخيص ' END || r.plot_number || ' — ' || to_char(r.expires_at,'YYYY-MM-DD') || '. يمكنك تقديم طلب تجديد من حسابك.',
 'renewal:'||r.id::text||':'||r.expires_at::text||':'||CASE WHEN r.expires_at<=now() THEN 'expired' ELSE '30days' END
 FROM public.license_requests r WHERE r.status='issued' AND r.deleted_at IS NULL AND r.expires_at IS NOT NULL AND r.expires_at<=now()+interval '30 days'
 AND NOT EXISTS(SELECT 1 FROM public.license_requests n WHERE n.parent_id=r.id AND n.kind='renewal' AND n.status='issued' AND n.deleted_at IS NULL AND n.expires_at>r.expires_at)
 ON CONFLICT(event_key) WHERE event_key IS NOT NULL DO NOTHING;
 GET DIAGNOSTICS inserted_count=ROW_COUNT;
 RETURN inserted_count;
END $$;
REVOKE ALL ON FUNCTION public.send_license_renewal_alerts() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.send_license_renewal_alerts() TO service_role;
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;