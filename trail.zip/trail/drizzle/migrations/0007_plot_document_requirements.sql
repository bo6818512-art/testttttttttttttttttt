UPDATE public.profile_documents
SET condition='always'
WHERE document_id=9;