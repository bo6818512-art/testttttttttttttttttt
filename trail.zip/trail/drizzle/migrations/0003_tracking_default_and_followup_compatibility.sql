ALTER TABLE public.license_requests ALTER COLUMN tracking_id SET DEFAULT '';
CREATE OR REPLACE FUNCTION public.validate_license_property() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$ DECLARE p public.licensing_plots; original public.license_requests; conflict text; BEGIN
 IF TG_OP='UPDATE' THEN IF NEW.property_id IS DISTINCT FROM OLD.property_id OR NEW.unit_id IS DISTINCT FROM OLD.unit_id OR NEW.floor IS DISTINCT FROM OLD.floor OR NEW.unit_number IS DISTINCT FROM OLD.unit_number THEN RAISE EXCEPTION 'Property and unit are read-only'; END IF; RETURN NEW; END IF;
 IF NEW.kind<>'new' THEN SELECT * INTO original FROM public.license_requests WHERE id=NEW.parent_id AND user_id=NEW.user_id FOR UPDATE; IF NOT FOUND THEN RAISE EXCEPTION 'Owned original required'; END IF; NEW.property_id:=original.property_id; NEW.unit_id:=original.unit_id; NEW.floor:=original.floor; NEW.unit_number:=original.unit_number; RETURN NEW; END IF;
 SELECT * INTO p FROM public.licensing_plots WHERE id=NEW.property_id AND enabled FOR SHARE; IF NOT FOUND THEN RAISE EXCEPTION 'كود القطعة غير موجود'; END IF;
 IF NEW.district IS DISTINCT FROM p.district OR upper(regexp_replace(NEW.plot_number,'[[:space:]_]','','g')) IS DISTINCT FROM p.code THEN RAISE EXCEPTION 'القطعة لا تتبع الحي المختار'; END IF;
 NEW.plot_number:=p.code; NEW.floor:=nullif(trim(NEW.floor),''); NEW.unit_number:=nullif(trim(NEW.unit_number),'');
 IF p.has_units OR p.code IN ('H5','SI4','N1') THEN NEW.unit_id:=public.license_slot(NEW.floor,NEW.unit_number); IF NEW.unit_id IS NULL THEN RAISE EXCEPTION 'الطابق ورقم الوحدة مطلوبان'; END IF; ELSE NEW.floor:=NULL; NEW.unit_number:=NULL; NEW.unit_id:=NULL; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(p.district||':'||p.code,0));
 conflict:=public.check_license_property(p.id,NEW.floor,NEW.unit_number); IF conflict IS NOT NULL THEN RAISE EXCEPTION 'يوجد ترخيص أو طلب جاري على هذا العقار: %',conflict USING ERRCODE='23505'; END IF;
 IF p.latitude IS NOT NULL AND p.longitude IS NOT NULL THEN NEW.selected_location:=jsonb_build_object('lat',p.latitude,'lng',p.longitude); END IF;
 RETURN NEW; END $$;