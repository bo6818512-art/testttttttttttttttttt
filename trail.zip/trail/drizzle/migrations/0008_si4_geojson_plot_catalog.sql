ALTER TABLE public.licensing_plots DROP CONSTRAINT valid_plot_code;
ALTER TABLE public.licensing_plots ADD CONSTRAINT valid_plot_code CHECK (char_length(btrim(code)) BETWEEN 1 AND 120);

DO $$
DECLARE definition text; original text;
BEGIN
  SELECT pg_get_functiondef('public.validate_license_request()'::regprocedure) INTO definition;
  original:=definition;
  definition:=replace(definition,'(''DIP'',''FIN'',''GOV2'',''INV'',''RES'',''MU'',''R7'',''R8'')','(''DIP'',''FIN'',''GOV2'',''INV'',''RES'',''MU'',''R7'',''R8'',''SI4'')');
  IF definition=original THEN RAISE EXCEPTION 'District validation source unavailable'; END IF;
  EXECUTE definition;
END $$;

INSERT INTO public.licensing_plots(code,district) VALUES
  ('ا-2','SI4'),('ا-1','SI4'),('ب-2','SI4'),('ب-4','SI4'),('ب-3','SI4'),('ج-3','SI4'),
  ('د10+د11','SI4'),('د12+د13','SI4'),('د14+د15+د16','SI4'),('ج-2','SI4'),('ب1','SI4'),('ج-1','SI4'),
  ('د2+د3','SI4'),('د4+د5','SI4'),('د6+د7+د8+د9','SI4'),('ج-4','SI4'),('ا-3','SI4'),('ا-4','SI4')
ON CONFLICT(code) DO UPDATE SET district=excluded.district,enabled=true;

CREATE FUNCTION public.active_license_plot_ids() RETURNS TABLE(property_id uuid) LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT DISTINCT p.id FROM public.licensing_plots p
  JOIN public.license_requests r ON r.property_id=p.id OR (
    r.property_id IS NULL AND r.district=p.district
    AND upper(regexp_replace(r.plot_number,'[[:space:]_]','','g'))=p.code
  )
  WHERE r.kind='new'
    AND (r.deleted_at IS NULL OR r.status='issued')
    AND r.status IN ('awaiting_document_review','awaiting_payment','awaiting_payment_review','submitted','under_review','needs_info','approved','pending_payment','payment_review','processing','issued')
$$;
REVOKE ALL ON FUNCTION public.active_license_plot_ids() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.active_license_plot_ids() TO authenticated;