UPDATE public.licensing_plots
SET district='GOV2', enabled=true
WHERE district='SI4'
  AND code IN (
    'ا-2','ا-1','ب-2','ب-4','ب-3','ج-3','د10+د11','د12+د13','د14+د15+د16',
    'ج-2','ب1','ج-1','د2+د3','د4+د5','د6+د7+د8+د9','ج-4','ا-3','ا-4'
  );