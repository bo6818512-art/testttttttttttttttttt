CREATE OR REPLACE FUNCTION public.save_portal_account(p_data jsonb) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  uid uuid:=auth.uid();
  saved_profile public.profiles;
  saved_company public.companies;
  incoming_company jsonb;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  SELECT * INTO saved_profile FROM public.profiles WHERE id=uid FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profile unavailable'; END IF;
  IF btrim(p_data->>'full_name') IS DISTINCT FROM btrim(saved_profile.full_name)
     OR p_data->>'national_id' IS DISTINCT FROM saved_profile.national_id
     OR p_data->>'account_type' IS DISTINCT FROM saved_profile.account_type THEN
    RAISE EXCEPTION 'Identity fields are read-only';
  END IF;
  IF length(trim(coalesce(p_data->>'phone','')))<7 OR length(trim(p_data->>'phone'))>30 THEN
    RAISE EXCEPTION 'Invalid contact phone';
  END IF;
  IF saved_profile.account_type='company' THEN
    SELECT * INTO saved_company FROM public.companies WHERE user_id=uid;
    IF NOT FOUND THEN RAISE EXCEPTION 'Company details unavailable'; END IF;
    incoming_company:=p_data->'company';
    IF incoming_company IS NULL
      OR btrim(incoming_company->>'name') IS DISTINCT FROM btrim(saved_company.name)
      OR btrim(incoming_company->>'commercial_number') IS DISTINCT FROM btrim(saved_company.commercial_number)
       OR incoming_company->>'commercial_path' IS DISTINCT FROM saved_company.commercial_path
      OR btrim(incoming_company->>'tax_number') IS DISTINCT FROM btrim(saved_company.tax_number)
       OR incoming_company->>'tax_path' IS DISTINCT FROM saved_company.tax_path
      OR btrim(incoming_company->>'representative_name') IS DISTINCT FROM btrim(saved_company.representative_name)
       OR incoming_company->>'representative_national_id' IS DISTINCT FROM saved_company.representative_national_id
      OR btrim(incoming_company->>'representative_phone') IS DISTINCT FROM btrim(saved_company.representative_phone)
      OR btrim(incoming_company->>'representative_role') IS DISTINCT FROM btrim(saved_company.representative_role) THEN
      RAISE EXCEPTION 'Company legal fields are read-only';
    END IF;
  END IF;
  UPDATE public.profiles SET phone=trim(p_data->>'phone') WHERE id=uid;
END $$;

REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE (phone) ON public.profiles TO authenticated;
REVOKE INSERT,UPDATE ON public.companies FROM authenticated;