import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { ArrowRight, MapPin, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { listApprovedPlots, listSI4PlotFeatures } from '@/lib/licensing.functions';
import { loadLicensingMap } from '@/lib/google-map-loader';
import { normalizePlotCode, type PlotFeature, type PortalPlot } from '@/lib/property-selection';
type MapOverlay = { plot?: PortalPlot; polygon?: google.maps.Polygon; label?: google.maps.Marker };
const specialCodes = new Set(['TOILET', 'E']);

function plotColor(plot: PortalPlot | undefined, selectedId: string) {
  if (!plot || plot.active) return '#858585';
  return plot.id === selectedId ? '#c28d32' : '#28776a';
}

function PlotMap({ plots, features, selectedId, onPick }: { plots: PortalPlot[]; features: PlotFeature[]; selectedId: string; onPick: (plot: PortalPlot, code: string) => void }) {
  const container = useRef<HTMLDivElement>(null);
  const callback = useRef(onPick);
  callback.current = onPick;
  const selected = useRef(selectedId);
  selected.current = selectedId;
  const overlays = useRef<MapOverlay[]>([]);
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'empty'>('loading');

  useEffect(() => {
    let disposed = false;
    const listeners: google.maps.MapsEventListener[] = [];
    const mapOverlays: MapOverlay[] = [];
    setState('loading');
    loadLicensingMap().then(maps => {
      if (disposed || !container.current) return;
      const map = new maps.Map(container.current, { center: { lat: 30.0098, lng: 31.748 }, zoom: 17, mapTypeId: 'satellite', clickableIcons: false, streetViewControl: false, gestureHandling: 'cooperative' });
      const bounds = new maps.LatLngBounds();
      const plotsByCode = new Map(plots.map(plot => [normalizePlotCode(plot.code), plot]));
      const labels: google.maps.Marker[] = [];
      features.forEach(feature => {
          const code = feature.properties.block_name;
          const normalized = normalizePlotCode(code);
          const plot = specialCodes.has(normalized) ? undefined : plotsByCode.get(normalized);
          const ring = feature.geometry.coordinates[0] ?? [];
          const paths = feature.geometry.coordinates.map(path => path.map(([lng, lat]) => ({ lat: lat ?? 0, lng: lng ?? 0 })));
          if (!ring.length || !paths.length) return;
          ring.forEach(([lng, lat]) => bounds.extend({ lat: lat ?? 0, lng: lng ?? 0 }));
          const color = plotColor(plot, selected.current);
          const polygon = new maps.Polygon({ map, paths, clickable: !!plot && !plot.active, fillColor: color, fillOpacity: plot ? 0.3 : 0.16, strokeColor: color, strokeOpacity: 0.95, strokeWeight: 2, zIndex: plot?.id === selected.current ? 3 : 1 });
          const listener = polygon.addListener('click', () => {
            if (plot && !plot.active) callback.current(plot, code);
          });
          listeners.push(listener);
          const points = ring.slice(0, -1);
          const center = points.reduce((sum, point) => ({ lat: sum.lat + (point[1] ?? 0) / points.length, lng: sum.lng + (point[0] ?? 0) / points.length }), { lat: 0, lng: 0 });
          const label = new maps.Marker({ map, position: center, title: code, label: { text: code, color: '#ffffff', fontSize: '12px', fontWeight: '700' }, icon: { path: maps.SymbolPath.CIRCLE, scale: 0 }, clickable: false, visible: false });
          labels.push(label);
          mapOverlays.push({ plot, polygon, label });
      });
      if (bounds.isEmpty()) { setState('empty'); return; }
      map.fitBounds(bounds);
      const updateLabels = () => labels.forEach(label => label.setVisible((map.getZoom() ?? 0) >= 17));
      listeners.push(map.addListener('zoom_changed', updateLabels));
      updateLabels();
      overlays.current = mapOverlays;
      setState('ready');
    }).catch(() => { if (!disposed) setState('error'); });
    return () => {
      disposed = true;
      listeners.forEach(listener => listener.remove());
      mapOverlays.forEach(overlay => { overlay.polygon?.setMap(null); overlay.label?.setMap(null); overlay.pointMarker?.setMap(null); });
      overlays.current = [];
    };
  }, [features, plots]);

  useEffect(() => {
    overlays.current.forEach(overlay => {
      const color = plotColor(overlay.plot, selectedId);
      overlay.polygon?.setOptions({ fillColor: color, strokeColor: color, zIndex: overlay.plot?.id === selectedId ? 3 : 1 });
    });
  }, [selectedId]);

  return <div className="relative overflow-hidden rounded-md"><div ref={container} className="h-80 w-full" aria-label="خريطة قطع الحي" />{state !== 'ready' && <p role="status" className="absolute inset-0 grid place-items-center bg-muted p-6 text-center text-muted-foreground">{state === 'loading' ? 'تحميل الخريطة…' : state === 'empty' ? 'لا توجد مواقع معتمدة على الخريطة.' : 'تعذر تحميل الخريطة التفاعلية.'}</p>}</div>;
}

export function PlotCodeMapPicker({ district, name, mapDataset, selectedId, onPick, onReset, onClear }: { district: string; name: string; mapDataset: 'SI4' | null; selectedId: string; onPick: (plot: PortalPlot) => void; onReset: () => void; onClear: () => void }) {
  const list = useServerFn(listApprovedPlots);
  const plotsQuery = useQuery({ queryKey: ['approved-plots', district], queryFn: () => list({ data: { district } }) });
  const getMapFeatures = useServerFn(listSI4PlotFeatures);
  const featuresQuery = useQuery({
    queryKey: ['si4-plot-map'],
    queryFn: () => getMapFeatures(),
    enabled: mapDataset === 'SI4',
    staleTime: Infinity,
  });
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');
  const plots = plotsQuery.data ?? [];
  const features = featuresQuery.data?.features ?? [];
  const selected = plots.find(plot => plot.id === selectedId);
  function choose(plot: PortalPlot, code: string) {
    onPick(plot);
    setSearch(code);
    setMessage('');
  }

  function changeCode(value: string) {
    setSearch(value);
    const normalized = normalizePlotCode(value);
    const plot = plots.find(item => normalizePlotCode(item.code) === normalized);
    if (plot && !plot.active) {
      choose(plot, value);
      return;
    }
    onClear();
    if (!normalized) setMessage('');
    else if (plot?.active) setMessage('يوجد ترخيص أو طلب قائم على هذه القطعة، ولا يمكن اختيارها.');
    else if (mapDataset === 'SI4' && features.some(feature => normalizePlotCode(feature.properties.block_name) === normalized && specialCodes.has(normalized))) setMessage('هذا الموقع ظاهر على الخريطة لكنه غير متاح للاختيار.');
    else setMessage('كود القطعة غير موجود في الحي المختار.');
  }

  return <div className="space-y-5 border-t pt-6"><div className="flex flex-wrap items-center justify-between gap-3"><h3 className="text-2xl font-bold">{name} <span dir="ltr">({district})</span></h3><Button variant="ghost" type="button" onClick={onReset}><ArrowRight />تغيير الحي</Button></div>
    <label className="flex items-center gap-3 rounded-md border bg-background px-4 py-3"><Search className="size-5 shrink-0 text-muted-foreground" /><input aria-label="كود القطعة" maxLength={120} placeholder="كود القطعة" className="min-w-0 flex-1 bg-transparent outline-none" dir="auto" value={search} onChange={event => changeCode(event.target.value)} /></label>
    {plotsQuery.isPending || (mapDataset === 'SI4' && featuresQuery.isPending) ? <p role="status">تحميل القطع والخريطة…</p> : plotsQuery.isError || (mapDataset === 'SI4' && featuresQuery.isError) ? <p role="alert" className="text-destructive">تعذر تحميل القطع أو الخريطة.</p> : mapDataset === 'SI4' ? <PlotMap plots={plots} features={features} selectedId={selectedId} onPick={choose} /> : null}
    {message && <p role="alert" className="text-destructive">{message}</p>}
    {mapDataset === 'SI4' && selected && <p role="status" className="flex flex-wrap items-center gap-2 border border-gold bg-muted p-4 font-semibold"><MapPin className="size-4" />القطعة المختارة: <b dir="auto">{selected.code}</b> — {name}</p>}
  </div>;
}