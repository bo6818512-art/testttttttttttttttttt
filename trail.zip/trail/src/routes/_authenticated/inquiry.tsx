import { createFileRoute, redirect } from '@tanstack/react-router';

export const Route = createFileRoute('/_authenticated/inquiry')({
	beforeLoad: () => {
		throw redirect({ to: '/my/requests' });
	},
});