import { createFileRoute } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Link } from '@tanstack/react-router';
import { PortalFrame, portalHead } from '@/components/portal-frame';
import { licenseRequestsOptions } from '@/components/license-records';
import { renewalEligible } from '@/lib/account';
import { useI18n } from '@/lib/i18n';
import { listLicenseRequests } from '@/lib/licensing.functions';

type LicenseRequest = Awaited<ReturnType<typeof listLicenseRequests>>[number];

export const Route = createFileRoute('/_authenticated/my/properties')({
  loader: ({ context }) => context.queryClient.ensureQueryData(licenseRequestsOptions),
  head: () => portalHead('عقاراتي', 'التراخيص والطلبات والوحدات المرتبطة بحسابك.'),
  component: Page,
});

const requestNames: Record<string, { ar: string; en: string }> = {
  new: { ar: 'طلب ترخيص', en: 'License request' },
  renewal: { ar: 'تجديد', en: 'Renewal' },
  activity_change: { ar: 'تعديل نشاط', en: 'Activity change' },
  ownership_transfer: { ar: 'نقل ملكية', en: 'Ownership transfer' },
};

const statusNames: Record<string, { ar: string; en: string }> = {
  awaiting_document_review: { ar: 'بانتظار مراجعة المستندات', en: 'Awaiting document review' },
  awaiting_payment: { ar: 'بانتظار الدفع', en: 'Awaiting payment' },
  awaiting_payment_review: { ar: 'الإيصال قيد المراجعة', en: 'Receipt under review' },
  under_review: { ar: 'قيد المراجعة', en: 'Under review' },
  needs_info: { ar: 'مطلوب استكمال المستندات', en: 'More information required' },
  rejected: { ar: 'مرفوض', en: 'Rejected' },
};

function displayDate(value: string | null, locale: string) {
  return value ? new Date(value).toLocaleDateString(locale) : '—';
}

function requestLabel(kind: string, english: boolean) {
  return requestNames[kind]?.[english ? 'en' : 'ar'] ?? kind;
}

function requestStatus(status: string, english: boolean) {
  return statusNames[status]?.[english ? 'en' : 'ar'] ?? status;
}

function unitTitle(record: LicenseRequest) {
  return record.unit_number
    ? `${record.plot_number} · ${record.floor ?? ''} / ${record.unit_number}`
    : record.plot_number;
}

function unitGroups(requests: LicenseRequest[], now: number) {
  const groups = new Map<string, LicenseRequest[]>();
  for (const request of requests) {
    const propertyKey = request.property_id ?? `${request.district ?? ''}:${request.plot_number}`;
    const unitKey = request.unit_id ?? `${request.floor ?? ''}:${request.unit_number ?? ''}`;
    const key = `${propertyKey}:${unitKey}`;
    const records = groups.get(key) ?? [];
    records.push(request);
    groups.set(key, records);
  }
  return Array.from(groups.values()).flatMap(records => {
    const latest = records[0];
    if (!latest) return [];
    const hasPending = records.some(record => record.status !== 'issued' && record.status !== 'rejected');
    const issued = records.filter(record => record.status === 'issued');
    const active = issued.some(record => record.expires_at !== null && Date.parse(record.expires_at) > now);
    const expired = issued.some(record => record.expires_at !== null && Date.parse(record.expires_at) <= now);
    const status = hasPending ? 'under_review' : active ? 'active' : expired ? 'expired' : 'rejected';
    return [{ key: `${latest.id}:${status}`, latest, status }];
  });
}

function badgeClass(status: string) {
  if (status === 'active') return 'text-primary';
  if (status === 'expired' || status === 'rejected') return 'text-destructive';
  return 'text-muted-foreground';
}

function Page() {
  const { data: requests } = useSuspenseQuery(licenseRequestsOptions);
  const { lang } = useI18n();
  const english = lang === 'en';
  const locale = english ? 'en-GB' : 'ar-EG';
  const now = Date.now();
  const issued = requests.filter(request => request.status === 'issued');
  const currentRequests = requests.filter(request => request.status !== 'issued' && request.status !== 'rejected');
  const units = unitGroups(requests, now);

  return <PortalFrame title={english ? 'My Properties' : 'عقاراتي'}>
    <div className="space-y-10">
      <section className="space-y-4 border-t-4 border-gold pt-6">
        <h2 className="text-xl font-bold">{english ? 'Issued licenses' : 'التراخيص الصادرة'}</h2>
        {issued.length === 0 ? <p className="text-muted-foreground">{english ? 'No issued licenses are linked to your account.' : 'لا توجد تراخيص صادرة مرتبطة بحسابك.'}</p> : issued.map(record => {
          const canRenew = renewalEligible(record, now);
          return <article key={record.id} className="space-y-3 rounded-md border bg-background p-5">
            <h3 className="text-lg font-bold">{unitTitle(record)}</h3>
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div><dt className="text-muted-foreground">{english ? 'Activity' : 'النشاط'}</dt><dd>{record.activity}</dd></div>
              <div><dt className="text-muted-foreground">{english ? 'License number' : 'رقم الترخيص'}</dt><dd dir="ltr">{record.license_number ?? record.tracking_id}</dd></div>
              <div><dt className="text-muted-foreground">{english ? 'Expiry date' : 'تاريخ الانتهاء'}</dt><dd>{displayDate(record.expires_at, locale)}</dd></div>
            </dl>
            {canRenew ? <Button asChild><Link to="/my/renew-license">{english ? 'Renew' : 'تجديد'}</Link></Button> : <Button type="button" disabled title={english ? 'Renewal opens in the final 60 days or after expiry.' : 'يتاح التجديد خلال آخر 60 يومًا أو بعد انتهاء الترخيص.'}>{english ? 'Renew' : 'تجديد'}</Button>}
          </article>;
        })}
      </section>

      <section className="space-y-4 border-t-4 border-gold pt-6">
        <h2 className="text-xl font-bold">{english ? 'Current requests' : 'الطلبات الحالية'}</h2>
        {currentRequests.length === 0 ? <p className="text-muted-foreground">{english ? 'No current requests.' : 'لا توجد طلبات حالية.'}</p> : currentRequests.map(record => (
          <article key={record.id} className="flex flex-wrap items-center justify-between gap-4 rounded-md border bg-background p-5">
            <div><h3 className="font-bold">{requestLabel(record.kind, english)} — {unitTitle(record)}</h3><p className="mt-2 text-sm text-muted-foreground">{english ? 'Track ID' : 'رقم المتابعة'}: <b dir="ltr">{record.tracking_id}</b></p></div>
            <span className={`text-sm font-bold ${badgeClass(record.status)}`}>{requestStatus(record.status, english)}</span>
          </article>
        ))}
      </section>

      <section className="space-y-4 border-t-4 border-gold pt-6">
        <h2 className="text-xl font-bold">{english ? 'All linked units' : 'كل الوحدات المرتبطة بحسابك'}</h2>
        {units.length === 0 ? <p className="text-muted-foreground">{english ? 'No units are linked to your account.' : 'لا توجد وحدات مرتبطة بحسابك.'}</p> : units.map(unit => {
          const statusNames = {
            active: english ? 'Active' : 'ساري',
            expired: english ? 'Expired' : 'منتهي',
            under_review: english ? 'Under review' : 'قيد المراجعة',
            rejected: english ? 'No issued license' : 'لم يصدر ترخيص',
          };
          return <article key={unit.key} className="flex flex-wrap items-center justify-between gap-4 rounded-md border bg-background p-5">
            <div><h3 className="font-bold">{unitTitle(unit.latest)}</h3><p className="mt-1 text-sm text-muted-foreground">{unit.latest.activity}</p></div>
            <span className={`text-sm font-bold ${badgeClass(unit.status)}`}>{statusNames[unit.status as keyof typeof statusNames]}</span>
          </article>;
        })}
      </section>
    </div>
  </PortalFrame>;
}