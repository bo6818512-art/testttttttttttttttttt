import { useEffect, useState, type FormEvent } from 'react';
import { createFileRoute } from '@tanstack/react-router';
import { queryOptions, useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { Download, Eye, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PortalFrame, portalHead } from '@/components/portal-frame';
import { supabase } from '@/integrations/supabase/client';
import { useI18n } from '@/lib/i18n';
import { getAccount, saveAccount } from '@/lib/account.functions';

const accountOptions = queryOptions({ queryKey: ['portal-account'], queryFn: () => getAccount() });

export const Route = createFileRoute('/_authenticated/my/data')({
  loader: ({ context }) => context.queryClient.ensureQueryData(accountOptions),
  head: () => portalHead('بياناتي', 'عرض بيانات الحساب وتعديل رقم التواصل.'),
  component: Page,
});

function PrivateCompanyDocument({ path, name, english }: { path: string; name: string; english: boolean }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function openDocument(download: boolean) {
    setBusy(true);
    setError('');
    try {
      const { data, error: signedUrlError } = await supabase.storage
        .from('company-documents')
        .createSignedUrl(path, 60, { download: download ? name : false });
      if (signedUrlError || !data?.signedUrl) throw signedUrlError ?? new Error('Document unavailable');
      const anchor = document.createElement('a');
      anchor.href = data.signedUrl;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      if (download) anchor.download = name;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
    } catch {
      setError(english ? 'Unable to open this document.' : 'تعذر فتح المستند.');
    } finally {
      setBusy(false);
    }
  }

  return <div className="flex flex-wrap items-center justify-between gap-3 border-b py-4 last:border-0"><span className="font-semibold">{name}</span><div className="flex gap-2"><Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => void openDocument(false)}><Eye />{english ? 'View' : 'عرض'}</Button><Button type="button" size="sm" variant="outline" disabled={busy} onClick={() => void openDocument(true)}><Download />{english ? 'Download' : 'تنزيل'}</Button></div>{error && <p role="alert" className="w-full text-sm text-destructive">{error}</p>}</div>;
}

function ReadOnlyField({ label, value, dir }: { label: string; value: string | null | undefined; dir?: 'ltr' | 'auto' }) {
  return <label className="block text-sm font-semibold">{label}<Input className="mt-2 bg-muted" value={value || '—'} readOnly dir={dir} /></label>;
}

function Page() {
  const { data } = useSuspenseQuery(accountOptions);
  const { lang } = useI18n();
  const english = lang === 'en';
  const queryClient = useQueryClient();
  const updateAccount = useServerFn(saveAccount);
  const [phone, setPhone] = useState(data.profile.phone);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const company = data.company;
  const accountType = data.profile.account_type === 'company' ? 'company' : 'individual';

  useEffect(() => setPhone(data.profile.phone), [data.profile.phone]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage('');
    setError('');
    try {
      await updateAccount({
        data: {
          full_name: data.profile.full_name,
          national_id: data.profile.national_id,
          phone,
          account_type: accountType,
          ...(company ? { company: {
            name: company.name,
            commercial_number: company.commercial_number,
            commercial_path: company.commercial_path,
            tax_number: company.tax_number,
            tax_path: company.tax_path,
            representative_name: company.representative_name,
            representative_national_id: company.representative_national_id,
            representative_phone: company.representative_phone,
            representative_role: company.representative_role,
          } } : {}),
        },
      });
      await queryClient.invalidateQueries({ queryKey: accountOptions.queryKey });
      setMessage(english ? 'Contact number updated.' : 'تم تحديث رقم التواصل.');
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : (english ? 'Unable to update contact details.' : 'تعذر تحديث بيانات التواصل.'));
    } finally {
      setBusy(false);
    }
  }

  return <PortalFrame title={english ? 'My Data' : 'بياناتي'}>
    <div className="space-y-8">
      <section className="space-y-5 border-t-4 border-gold pt-6">
        <h2 className="text-xl font-bold">{english ? 'Personal information' : 'البيانات الشخصية'}</h2>
        <div className="grid gap-5 md:grid-cols-2">
          <ReadOnlyField label={english ? 'Full name' : 'الاسم بالكامل'} value={data.profile.full_name} />
          <ReadOnlyField label={english ? 'National ID' : 'الرقم القومي'} value={data.profile.national_id} dir="ltr" />
          <ReadOnlyField label={english ? 'Email' : 'البريد الإلكتروني'} value={data.email} dir="ltr" />
          <form onSubmit={submit} className="space-y-3">
            <label className="block text-sm font-semibold">{english ? 'Contact phone' : 'رقم التواصل'}<Input className="mt-2" type="tel" dir="ltr" autoComplete="tel" maxLength={30} minLength={7} required value={phone} onChange={event => setPhone(event.target.value)} /></label>
            <Button type="submit" disabled={busy || phone.trim() === data.profile.phone || (accountType === 'company' && !company)}>{busy ? (english ? 'Saving…' : 'جارٍ الحفظ…') : <><Save />{english ? 'Save contact number' : 'حفظ رقم التواصل'}</>}</Button>
            {message && <p role="status" className="text-sm text-primary">{message}</p>}
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          </form>
        </div>
      </section>

      {accountType === 'company' && <>
        <section className="space-y-5 border-t-4 border-gold pt-6">
          <h2 className="text-xl font-bold">{english ? 'Company information' : 'بيانات الشركة'}</h2>
          {company ? <div className="grid gap-5 md:grid-cols-2">
            <ReadOnlyField label={english ? 'Company name' : 'اسم الشركة'} value={company.name} />
            <ReadOnlyField label={english ? 'Commercial Register' : 'رقم السجل التجاري'} value={company.commercial_number} dir="ltr" />
            <ReadOnlyField label={english ? 'Tax Card number' : 'رقم البطاقة الضريبية'} value={company.tax_number} dir="ltr" />
          </div> : <p role="status" className="text-muted-foreground">{english ? 'Company details are not available.' : 'بيانات الشركة غير متاحة.'}</p>}
        </section>
        {company && <section className="space-y-5 border-t-4 border-gold pt-6">
          <h2 className="text-xl font-bold">{english ? 'Company representative' : 'ممثل الشركة'}</h2>
          <div className="grid gap-5 md:grid-cols-2">
            <ReadOnlyField label={english ? 'Representative name' : 'اسم الممثل'} value={company.representative_name} />
            <ReadOnlyField label={english ? 'Representative national ID' : 'الرقم القومي للممثل'} value={company.representative_national_id} dir="ltr" />
            <ReadOnlyField label={english ? 'Representative phone' : 'هاتف الممثل'} value={company.representative_phone} dir="ltr" />
            <ReadOnlyField label={english ? 'Representative role' : 'صفة الممثل'} value={company.representative_role} />
          </div>
        </section>}
        {company && <section className="space-y-3 border-t-4 border-gold pt-6">
          <h2 className="text-xl font-bold">{english ? 'Uploaded company documents' : 'مستندات الشركة المرفوعة'}</h2>
          <div className="divide-y rounded-md border bg-background px-4">
            <PrivateCompanyDocument path={company.commercial_path} name="commercial-register.pdf" english={english} />
            <PrivateCompanyDocument path={company.tax_path} name="tax-card.pdf" english={english} />
          </div>
        </section>}
      </>}
    </div>
  </PortalFrame>;
}